﻿# BÀI LÀM - ÔN TẬP NGÀY 3
- **Họ tên: lê trọng quang**
- **Lớp: cntt1**
- **Link repository:**
- **Hệ điều hành (Windows/macOS):**

## Bài 1. README.md
> README.md được chấm trực tiếp trên file `README.md` ở thư mục gốc. Đánh dấu `[x]` vào các mục đã làm để tự kiểm tra.

- [x] Heading 1: tên dự án
- [x] Ít nhất 2 heading cấp 2
- [x] Mô tả ngắn có cả **in đậm** và *in nghiêng*
- [x] Bảng `Thư mục | Nội dung`, ít nhất 3 dòng dữ liệu
- [x] Danh sách đánh số ít nhất 3 bước
- [x] Code block chứa lệnh PowerShell/Terminal liệt kê nội dung dự án
- [x] Task list ít nhất 2 công việc, có ít nhất 1 mục đã hoàn thành
- [x] Blockquote nhắc không upload `.env`

## Bài 2. Excel

> Công thức được chấm trực tiếp trên file `data/hoc_phi_thang_10.xlsx`

- Số dòng còn hiển thị sau khi lọc (câu d): 8 .
- Câu e - Vì sao vùng tra cứu cần dấu \$:
-vì dấu `$` dùng để tạo tham chiếu tuyệt đối khi kéo công thức xuống các ô bên dưới, vùng dữ liệu của bảng tra cứu sẽ được cố định cố định và không bị dịch chuyển theo dòng. Nếu bỏ dấu `$`, vùng tra cứu sẽ chuyển thành tham chiếu tương đối và bị tịnh tiến xuống dưới theo từng dòng, khiến Excel không tìm thấy dữ liệu ở các dòng phía trên và trả về lỗi `#N/A `ở các dòng phía dưới.

## Tự chấm (điền sau khi có đáp án)

- **Điểm tự chấm:** ..../100
- **Lỗi mình đã mắc và cách sửa:

